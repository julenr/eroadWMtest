'use strict';

/**
 * @ngdoc function
 * @name eroadWmApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the eroadWmApp
 */
angular.module('eroadWmApp')
  .controller('MainCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
